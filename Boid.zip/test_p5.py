from p5 import *
from Boid import *
x = 100
y = 100

xspeed = 1
yspeed = 3.3
boids = []
def setup():
    size(640, 360)
    background(255)
    # boids.append(Boid())

def draw():
    # for boid in boids:
    #     boid.dosomething()
    fill(255, 10)
    rect((0, 0), width, height)

    stroke(0)
    fill(175)
    a = Vector(300, 100)
    circle((a.x, a.y), 16)

if __name__ == '__main__':
    run()